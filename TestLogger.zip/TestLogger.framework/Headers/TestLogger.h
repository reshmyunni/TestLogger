//
//  TestLogger.h
//  TestLogger
//
//  Created by Reshmy Manuraj on 14/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for TestLogger.
FOUNDATION_EXPORT double TestLoggerVersionNumber;

//! Project version string for TestLogger.
FOUNDATION_EXPORT const unsigned char TestLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestLogger/PublicHeader.h>


